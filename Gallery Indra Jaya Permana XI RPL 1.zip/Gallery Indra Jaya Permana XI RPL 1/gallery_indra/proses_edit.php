<?php
session_start();
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $fotoID = $_POST['FotoID'];
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = $_POST['tanggal'];
    $albumID = $_POST['album'];
    $userID = $_SESSION['UserID'];

    // Cek apakah ada file foto yang diunggah
    if (!empty($_FILES['foto']['name'])) {
        $foto = $_FILES['foto'];
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($foto["name"]);

        // Pindahkan file yang diunggah ke folder tujuan
        if (move_uploaded_file($foto["tmp_name"], $targetFile)) {
            // Update data dengan foto baru
            $query = "UPDATE foto 
                      SET JudulFoto = '$judul', DeskripsiFoto = '$deskripsi', TanggalUnggah = '$tanggal', 
                          LokasiFoto = '{$foto['name']}', AlbumID = '$albumID', UserID = '$userID' 
                      WHERE FotoID = '$fotoID'";
        } else {
            echo "Gagal mengunggah foto baru.";
            exit();
        }
    } else {
        // Update data tanpa mengubah foto
        $query = "UPDATE foto 
                  SET JudulFoto = '$judul', DeskripsiFoto = '$deskripsi', TanggalUnggah = '$tanggal', 
                      AlbumID = '$albumID', UserID = '$userID' 
                  WHERE FotoID = '$fotoID'";
    }

    // Jalankan query
    if (mysqli_query($con, $query)) {
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Terjadi kesalahan: " . mysqli_error($con);
    }
} else {
    echo "Akses tidak valid.";
}
?>
