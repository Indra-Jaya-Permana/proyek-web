<?php
include "header.php"; // session_start() sudah di header.php
include "koneksi.php";

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

$Username = $_SESSION['Username'];
$PeranID = $_SESSION['PeranID'];

// Periksa apakah ID foto diterima
if (isset($_GET['id'])) {
    $fotoID = $_GET['id'];

    // Ambil data foto berdasarkan FotoID
    $query_foto = "
        SELECT 
            f.FotoID, f.JudulFoto, f.DeskripsiFoto, f.TanggalUnggah, f.LokasiFoto, 
            a.NamaAlbum, u.Username, 
            (SELECT COUNT(*) FROM komentarfoto WHERE FotoID = f.FotoID) AS JumlahKomentar,
            (SELECT COUNT(*) FROM likefoto WHERE FotoID = f.FotoID) AS JumlahLike
        FROM foto f
        JOIN album a ON f.AlbumID = a.AlbumID
        JOIN user u ON f.UserID = u.UserID
        WHERE f.FotoID = '$fotoID'
        LIMIT 1";

    $result_foto = mysqli_query($con, $query_foto);

    // Periksa apakah foto ditemukan
    if (mysqli_num_rows($result_foto) > 0) {
        $foto = mysqli_fetch_assoc($result_foto);
    } else {
        echo "Foto tidak ditemukan!";
        exit();
    }
} else {
    echo "ID foto tidak ditemukan!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Foto</title>
    <!-- Tambahkan Bootstrap dan Font Awesome -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .photo-card {
            display: flex;
            gap: 20px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 20px auto;
        }
        .photo-image img {
            border-radius: 10px;
            max-width: 300px;
            width: 100%;
        }
        .photo-details {
            flex: 1;
        }
        .photo-stats {
            display: inline-block;
            margin-right: 15px;
            font-size: 1.1rem;
        }
        .photo-stats i {
            color: #ff4757;
            margin-right: 5px;
        }
        .photo-actions {
            margin-top: 20px;
        }
        .photo-actions a {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h2 class="text-center">Detail Foto</h2>
        <hr>
        <div class="photo-card">
            <div class="photo-image">
                <img src="uploads/<?php echo $foto['LokasiFoto']; ?>" alt="<?php echo htmlspecialchars($foto['JudulFoto']); ?>" />
            </div>
            <div class="photo-details">
                <h3><?php echo htmlspecialchars($foto['JudulFoto']); ?></h3>
                <p><strong>Deskripsi:</strong> <?php echo htmlspecialchars($foto['DeskripsiFoto']); ?></p>
                <p><strong>Tanggal Unggah:</strong> <?php echo $foto['TanggalUnggah']; ?></p>
                <p><strong>Album:</strong> <?php echo $foto['NamaAlbum']; ?></p>
                <p><strong>Diunggah oleh:</strong> <?php echo $foto['Username']; ?></p>
                <p>
                    <span class="photo-stats">
                        <i class="fa-solid fa-comment"></i> <?php echo $foto['JumlahKomentar']; ?> Komentar
                    </span>
                    <span class="photo-stats">
                        <i class="fa-solid fa-heart"></i> <?php echo $foto['JumlahLike']; ?> Suka
                    </span>
                </p>
                <?php if ($PeranID == 1): ?>
                <div class="photo-actions">
                    <a href="edit.php?id=<?php echo $foto['FotoID']; ?>" class="btn btn-primary">Edit</a>
                    <a href="delete.php?id=<?php echo $foto['FotoID']; ?>" 
                       class="btn btn-danger" 
                       onclick="return confirm('Yakin ingin menghapus foto ini?')">Hapus</a>
                </div>
                <?php endif;?>
            </div>
        </div>
        <hr>
        <a href="dashboard.php?id=<?php echo $foto['FotoID']; ?>" class="btn btn-secondary">Kembali</a>
    </div>
</body>


</html>

<?php include "footer.php"; ?>
