<?php
session_start();
header('Content-Type: application/json'); // Set response header to JSON

include "koneksi.php";

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    echo json_encode([
        "status" => "error",
        "message" => "Anda harus login untuk memberikan like."
    ]);
    exit();
}

// Periksa apakah FotoID dikirim melalui POST
if (!isset($_POST['FotoID'])) {
    echo json_encode([
        "status" => "error",
        "message" => "FotoID tidak ditemukan."
    ]);
    exit();
}

$FotoID = $_POST['FotoID'];
$UserID = $_SESSION['UserID'];

// Periksa apakah FotoID valid
$checkFotoQuery = "SELECT * FROM foto WHERE FotoID = ?";
$stmt = mysqli_prepare($con, $checkFotoQuery);
mysqli_stmt_bind_param($stmt, 'i', $FotoID);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Foto tidak ditemukan."
    ]);
    exit();
}

// Periksa apakah pengguna sudah menyukai foto ini
$checkLikeQuery = "SELECT * FROM likefoto WHERE FotoID = ? AND UserID = ?";
$stmt = mysqli_prepare($con, $checkLikeQuery);
mysqli_stmt_bind_param($stmt, 'ii', $FotoID, $UserID);
mysqli_stmt_execute($stmt);
$likeResult = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($likeResult) > 0) {
    // Jika sudah like, maka unlike
    $deleteLikeQuery = "DELETE FROM likefoto WHERE FotoID = ? AND UserID = ?";
    $stmt = mysqli_prepare($con, $deleteLikeQuery);
    mysqli_stmt_bind_param($stmt, 'ii', $FotoID, $UserID);
    mysqli_stmt_execute($stmt);

    // Hitung ulang jumlah like
    $likeCountQuery = "SELECT COUNT(*) AS JumlahLike FROM likefoto WHERE FotoID = ?";
    $stmt = mysqli_prepare($con, $likeCountQuery);
    mysqli_stmt_bind_param($stmt, 'i', $FotoID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $likeCount = mysqli_fetch_assoc($result)['JumlahLike'];

    echo json_encode([
        "status" => "unliked",
        "message" => "Anda telah membatalkan like.",
        "JumlahLike" => $likeCount
    ]);
} else {
    // Jika belum like, maka tambah like
    $insertLikeQuery = "INSERT INTO likefoto (FotoID, UserID, TanggalLike, status) VALUES (?, ?, NOW(), 'like')";
    $stmt = mysqli_prepare($con, $insertLikeQuery);
    mysqli_stmt_bind_param($stmt, 'ii', $FotoID, $UserID);
    mysqli_stmt_execute($stmt);

    // Hitung ulang jumlah like
    $likeCountQuery = "SELECT COUNT(*) AS JumlahLike FROM likefoto WHERE FotoID = ?";
    $stmt = mysqli_prepare($con, $likeCountQuery);
    mysqli_stmt_bind_param($stmt, 'i', $FotoID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $likeCount = mysqli_fetch_assoc($result)['JumlahLike'];

    echo json_encode([
        "status" => "liked",
        "message" => "Anda telah menyukai foto ini.",
        "JumlahLike" => $likeCount
    ]);
}
?>
