<?php
session_start();
include "header.php";
include "koneksi.php";

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

// Query untuk mendapatkan semua album dari database
$query_album = "SELECT AlbumID, NamaAlbum, Deskripsi, TanggalDibuat FROM album";
$result_album = mysqli_query($con, $query_album);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Album</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .form-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h2, h3 {
            text-align: center;
            margin-bottom: 20px;
        }

        .btn.white {
            background-color: #007bff;
            color: white;
        }

        .btn.white:hover {
            background-color: #0056b3;
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }

        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Tombol Kembali -->
    <a href="dashboard.php" class="back-button">←</a>

    <!-- Form Tambah Album -->
    <div class="form-container">
        <form action="proses_tambah_album.php" method="POST">
            <h2>Tambah Album</h2>
            <div class="mb-3">
                <label for="NamaAlbum" class="form-label">Nama Album</label>
                <input type="text" name="NamaAlbum" id="NamaAlbum" class="form-control" placeholder="Masukkan nama album" required>
            </div>
            <div class="mb-3">
                <label for="Deskripsi" class="form-label">Deskripsi</label>
                <textarea name="Deskripsi" id="Deskripsi" class="form-control" placeholder="Masukkan deskripsi album" required></textarea>
            </div>
            <button type="submit" class="btn w-100 white">Tambah Album</button>
        </form>
    </div>

    <!-- List Album -->
    <div class="form-container">
        <h3>List Album</h3>
        <ul class="list-group">
            <?php if (mysqli_num_rows($result_album) > 0): ?>
                <?php while ($album = mysqli_fetch_assoc($result_album)): ?>
                    <li class="list-group-item">
                        <strong><?php echo htmlspecialchars($album['NamaAlbum']); ?></strong> 
                        - <?php echo htmlspecialchars($album['Deskripsi']); ?>
                        <br>
                        <small class="text-muted">Dibuat pada: <?php echo htmlspecialchars($album['TanggalDibuat']); ?></small>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <li class="list-group-item text-center">Belum ada album yang ditambahkan.</li>
            <?php endif; ?>
        </ul>
    </div>
</body>
</html>
<?php include "footer.php"; ?>
