<?php
include "koneksi.php";
session_start();

// Periksa apakah pengguna sudah login dan memiliki akses admin
if (!isset($_SESSION['UserID']) || $_SESSION['PeranID'] != 1) {
    echo "<script>alert('Anda tidak memiliki akses ke halaman ini.'); window.location.href = 'index.php';</script>";
    exit();
}

// Periksa apakah FotoID ada dalam parameter URL
if (isset($_GET['id'])) {
    $fotoID = $_GET['id'];

    // Hapus data komentar terkait dengan FotoID
    $deleteComments = "DELETE FROM komentarfoto WHERE FotoID = '$fotoID'";
    mysqli_query($con, $deleteComments);

    // Hapus data like terkait dengan FotoID
    $deleteLikes = "DELETE FROM likefoto WHERE FotoID = '$fotoID'";
    mysqli_query($con, $deleteLikes);

    // Ambil lokasi file foto sebelum menghapus dari database
    $getFotoQuery = "SELECT LokasiFoto FROM foto WHERE FotoID = '$fotoID'";
    $fotoResult = mysqli_query($con, $getFotoQuery);

    if ($fotoResult && mysqli_num_rows($fotoResult) > 0) {
        $fotoRow = mysqli_fetch_assoc($fotoResult);
        $filePath = "uploads/" . $fotoRow['LokasiFoto'];

        // Hapus file foto dari server
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }

    // Hapus data foto dari database
    $deleteFoto = "DELETE FROM foto WHERE FotoID = '$fotoID'";
    if (mysqli_query($con, $deleteFoto)) {
        echo "<script>alert('Foto berhasil dihapus.'); window.location.href = 'gallery.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus foto.'); window.location.href = 'gallery.php';</script>";
    }
} else {
    echo "<script>alert('ID foto tidak valid.'); window.location.href = 'gallery.php';</script>";
}
?>
