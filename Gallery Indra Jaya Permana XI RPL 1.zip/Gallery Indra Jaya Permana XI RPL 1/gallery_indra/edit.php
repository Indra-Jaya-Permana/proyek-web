<?php
include "header.php"; // session_start() sudah di header.php
include "koneksi.php";
$Username = $_SESSION['Username'];


// Ambil Album dari database
$query_album = "SELECT * FROM album";
$result_album = mysqli_query($con, $query_album);

$query = "SELECT FotoID, JudulFoto, DeskripsiFoto, TanggalUnggah, LokasiFoto, AlbumID, UserID FROM foto";
$result = mysqli_query($con, $query);

// Cek apakah ID foto diterima
if (isset($_GET['id'])) {
    $fotoID = $_GET['id'];

    // Ambil data foto dari database berdasarkan FotoID
    $query = "SELECT * FROM foto WHERE FotoID = '$fotoID'";
    $result = mysqli_query($con, $query);

    // Jika foto ditemukan
    if (mysqli_num_rows($result) > 0) {
        $foto = mysqli_fetch_assoc($result);
    } else {
        echo "Foto tidak ditemukan!";
        exit();
    }
} else {
    echo "ID foto tidak ditemukan!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Foto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div class="container py-4">
        
        <center><h2 class="mb-4">Form Pengeditan Foto </h2></center>

        <hr>

        <form action="proses_edit.php" method="POST" enctype="multipart/form-data">
            <!-- Hidden input to store FotoID for the update process -->
            <input type="hidden" name="FotoID" value="<?php echo $foto['FotoID']; ?>">

            <!-- Title field -->
            <div class="mb-3">
                <label for="judul" class="form-label">Judul Foto:</label>
                <input id="judul" name="judul" type="text" class="form-control" value="<?php echo htmlspecialchars($foto['JudulFoto']); ?>" required>
            </div>

            <!-- Description field -->
            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi Foto:</label>
                <textarea id="deskripsi" name="deskripsi" class="form-control" rows="4" required><?php echo htmlspecialchars($foto['DeskripsiFoto']); ?></textarea>
            </div>

            <!-- Date field -->
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal Unggah:</label>
                <input id="tanggal" name="tanggal" type="date" class="form-control" value="<?php echo $foto['TanggalUnggah']; ?>" required>
            </div>

            <!-- File upload field -->
            <div class="mb-3">
                <label for="foto" class="form-label">Upload Foto:</label>
                <input id="foto" name="foto" type="file" class="form-control">
            </div>

            <!-- Displaying current photo -->
            <div class="mb-3">
                <label for="currentFoto" class="form-label">Foto Saat Ini:</label>
                <div>
                    <img src="uploads/<?php echo htmlspecialchars($foto['LokasiFoto']); ?>" alt="Foto Saat Ini" width="150">
                </div>
            </div>

            <!-- Album selection -->
            <div class="mb-3">
                <label for="album" class="form-label">Album:</label>
                <select id="album" name="album" class="form-select" required>
                    <option disabled selected>Silahkan Pilih</option>
                    <?php 
                    while ($row = mysqli_fetch_assoc($result_album)) {
                        $selected = ($row['AlbumID'] == $foto['AlbumID']) ? 'selected' : '';
                        echo "<option value='{$row['AlbumID']}' {$selected}>{$row['NamaAlbum']}</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Buttons -->
            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Edit Foto</button>
                <a href="dashboard.php" class="btn btn-secondary">Batal</a>
            </div>
        </form>
    </div>

    <!-- Footer -->
    <?php include "footer.php"; ?>

</body>
</html>
