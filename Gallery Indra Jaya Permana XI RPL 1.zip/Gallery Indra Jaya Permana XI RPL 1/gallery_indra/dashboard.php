<?php
include "header.php";
include "koneksi.php";

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

$Username = $_SESSION['Username'];
$PeranID = $_SESSION['PeranID'];

// Query untuk mendapatkan semua album
$albumQuery = mysqli_query($con, "SELECT AlbumID, NamaAlbum FROM album");

// Variabel untuk search dan filter
$searchKeyword = isset($_GET['search']) ? $_GET['search'] : '';
$filterAlbum = isset($_GET['album']) ? $_GET['album'] : '';

// Query untuk mendapatkan data foto dengan search dan filter
$query = "
    SELECT 
        f.FotoID, f.JudulFoto, f.DeskripsiFoto, f.TanggalUnggah, f.LokasiFoto, 
        a.NamaAlbum, u.Username, 
        (SELECT COUNT(*) FROM komentarfoto WHERE FotoID = f.FotoID) AS JumlahKomentar,
        (SELECT COUNT(*) FROM likefoto WHERE FotoID = f.FotoID) AS JumlahLike
    FROM foto f
    JOIN album a ON f.AlbumID = a.AlbumID
    JOIN user u ON f.UserID = u.UserID
    WHERE f.JudulFoto LIKE '%$searchKeyword%'
";

if ($filterAlbum !== '') {
    $query .= " AND a.AlbumID = '$filterAlbum'";
}

$query .= " ORDER BY f.FotoID ASC";
$fotoQuery = mysqli_query($con, $query);

// Query untuk memeriksa apakah pengguna sudah like
$checkUserLikeQuery = "SELECT * FROM likefoto WHERE FotoID = ? AND UserID = ?";
$stmt = mysqli_prepare($con, $checkUserLikeQuery);
mysqli_stmt_bind_param($stmt, 'ii', $foto['FotoID'], $_SESSION['UserID']);
mysqli_stmt_execute($stmt);
$userLikeResult = mysqli_stmt_get_result($stmt);
$isLiked = mysqli_num_rows($userLikeResult) > 0;
?>

<style>
    /* Hero Section */
    .hero {
            height: 90vh;
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('Uploads/baground1.jpg') no-repeat center center/cover;
            color: white;
            padding: 80px 0;
            text-align: center;
            
        }
        .hero h1 {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        .hero p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .logo {
            width: 150px;
            margin: 20px auto;
            display: block;
        }

                /* Animasi Mengetik */
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid white;
        animation: typing 6s steps(60, end), blink 0.6s step-end infinite alternate;
        font-size: 1.2rem;
    }

    @keyframes typing {
        0% {
            width: 0;
        }
        100% {
            width: 100%; /* Menyelesaikan seluruh teks */
        }
    }

    @keyframes blink {
        0%, 100% {
            border-color: transparent;
        }
        50% {
            border-color: white;
        }
    }

    /* Not Found Style */
    .not-found {
        text-align: center;
        padding: 60px 20px;
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .not-found h3 {
        font-size: 2rem;
        font-weight: 700;
        color: #d9534f;
    }

    .not-found p {
        font-size: 1rem;
        color: #777;
    }
</style>

    <!-- Hero Section -->
    <div class="hero">
        <div class="container">
            <img class="logo" src="Uploads/logo.png" alt="Logo">
            <h1>Selamat Datang di Portify, <?php echo $Username; ?></h1>
            <p class="typing-text">Platform modern untuk mengelola dan berbagi foto. Temukan pengalaman terbaik dengan desain kami yang user-friendly.</p>
        </div>
    </div>

    <div class="container py-4">
    <!-- Form Search dan Filter -->
    <form method="GET" class="mb-4">
        <center><h2>Gallery Portify</h2></center>
        <hr>
        <div class="row">
            <div class="col-md-6">
                <input type="text" name="search" class="form-control" placeholder="Cari judul foto..." value="<?php echo $searchKeyword; ?>">
            </div>
            <div class="col-md-4">
                <select name="album" class="form-select">
                    <option value="">Semua Album</option>
                    <?php while ($album = mysqli_fetch_assoc($albumQuery)): ?>
                        <option value="<?php echo $album['AlbumID']; ?>" <?php if ($album['AlbumID'] == $filterAlbum) echo 'selected'; ?>>
                            <?php echo $album['NamaAlbum']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
        <hr>
    </form>

        <?php if (mysqli_num_rows($fotoQuery) > 0): ?>
            <!-- Jika hasil ditemukan -->
            <div class="row">
                <?php while ($foto = mysqli_fetch_assoc($fotoQuery)): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card shadow-sm">
                            <img src="uploads/<?php echo $foto['LokasiFoto']; ?>" class="card-img-top" alt="<?php echo $foto['JudulFoto']; ?>">
                            <div class="card-body">
                                <center><h5 class="card-title"><?php echo $foto['JudulFoto']; ?></h5></center>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
            <?php else: ?>
                <!-- Jika tidak ada hasil -->
                <div class="not-found">
                    <h3>Foto tidak ditemukan</h3>
                    <p>Coba gunakan kata kunci atau filter yang berbeda.</p>
                </div>
            <?php endif; ?>
        </div>
        <hr>
    </form>

    <div class="row">
        <?php while ($foto = mysqli_fetch_assoc($fotoQuery)): ?>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <img src="uploads/<?php echo $foto['LokasiFoto']; ?>" class="card-img-top" alt="<?php echo $foto['JudulFoto']; ?>">
                    <div class="card-body">
                        <center><h5 class="card-title"><?php echo $foto['JudulFoto']; ?></h5></center>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="js/script.js"></script>

<?php include "footer.php"; ?>
