<?php
session_start();
include "koneksi.php";

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

$NamaAlbum = $_POST['NamaAlbum'];
$Deskripsi = $_POST['Deskripsi'];
$UserID = $_SESSION['UserID'];

// Memastikan nama album dan deskripsi tidak kosong
if (!empty($NamaAlbum) && !empty($Deskripsi)) {
    $query = "INSERT INTO album (NamaAlbum, Deskripsi, TanggalDibuat, UserID) VALUES ('$NamaAlbum', '$Deskripsi', NOW(), '$UserID')";
    mysqli_query($con, $query);
}

// Arahkan kembali ke halaman tambah_album.php
header("Location: tambah_album.php");
exit();
?>
