<?php
include "header.php";
?>
<!--section-->
<section id="contact" class="contact section py-5 bg-light">
    <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="text-center mb-5">
            <h2 class="text-primary">Contact</h2>
        </div>

        <div class="info-wrap">
            <div class="row gy-4">
                <div class="col-lg-4">
                    <div class="info-item d-flex align-items-center bg-white shadow-sm rounded p-3">
                        <i class="bi bi-geo-alt text-primary fs-3 me-3"></i>
                        <div>
                            <h4 class="text-dark">Location</h4>
                            <p class="text-muted m-0">Bandung</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="info-item d-flex align-items-center bg-white shadow-sm rounded p-3">
                        <i class="bi bi-telephone text-primary fs-3 me-3"></i>
                        <div>
                            <h4 class="text-dark">Call</h4>
                            <p class="text-muted m-0">+62 812 3456 789</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="info-item d-flex align-items-center bg-white shadow-sm rounded p-3">
                        <i class="bi bi-envelope text-primary fs-3 me-3"></i>
                        <div>
                            <h4 class="text-dark">Email</h4>
                            <p class="text-muted m-0">Portify@gmail.com</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <form action="kirim_pesan.php" method="post" class="php-email-form mt-5 bg-white shadow-sm p-4 rounded" data-aos="fade-up" data-aos-delay="300">
            <div class="row gy-3">
                <div class="col-md-6">
                    <input type="text" name="name" class="form-control" placeholder="Your Name" required>
                </div>
                <div class="col-md-6">
                    <input type="email" class="form-control" name="email" placeholder="Your Email" required>
                </div>
                <div class="col-md-12">
                    <input type="text" class="form-control" name="subject" placeholder="Subject" required>
                </div>
                <div class="col-md-12">
                    <textarea class="form-control" name="message" rows="6" placeholder="Message" required></textarea>
                </div>
                <div class="col-md-12 text-center">
                    
                    <button type="submit" class="btn btn-primary mt-3">Send Message</button>
                </div>
            </div>
        </form>
    </div>
</section>


<?php
include "footer.php";
?>