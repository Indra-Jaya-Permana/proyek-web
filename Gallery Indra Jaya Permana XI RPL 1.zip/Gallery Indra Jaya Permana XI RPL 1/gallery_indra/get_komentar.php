<?php
include "koneksi.php";

if (isset($_GET['fotoid'])) {
    $fotoID = intval($_GET['fotoid']);
    $query = "
        SELECT k.IsiKomentar, u.Username, k.TanggalKomentar 
        FROM komentarfoto k
        JOIN user u ON k.UserID = u.UserID
        WHERE k.FotoID = $fotoID
        ORDER BY k.TanggalKomentar DESC";
    $result = mysqli_query($con, $query);

    $comments = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $comments[] = $row;
    }
    echo json_encode($comments);
}
?>
