<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $NamaLengkap = $_POST['NamaLengkap'];
    $Username = $_POST['Username'];
    $Email = $_POST['Email'];
    $Password = md5($_POST['Password']);
    $Alamat = $_POST['Alamat'];
    $PeranID = 2;  // Default PeranID set to 2 for 'User'

    // Periksa apakah Username atau Email sudah terdaftar
    $query_check = "SELECT * FROM user WHERE Username = ? OR Email = ?";
    $stmt_check = $con->prepare($query_check);
    $stmt_check->bind_param("ss", $Username, $Email);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        $error_message = "Username atau Email sudah terdaftar!";
    } else {
        // Insert ke tabel user
        $query = "INSERT INTO user (NamaLengkap, Username, PeranID, Email, Password, Alamat) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->bind_param("ssisss", $NamaLengkap, $Username, $PeranID, $Email, $Password, $Alamat);

        if ($stmt->execute()) {
            $_SESSION['Username'] = $Username;
            header("Location: login.php");
            exit();
        } else {
            $error_message = "Registrasi gagal, coba lagi.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">

    <style>
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }

        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Tombol Kembali -->
    <form action="index.php" method="POST" style="position: relative;">
        <button type="submit" class="back-button">
            ←
        </button>
    </form>
<div class="form-container">
    <form action="register.php" method="POST">
        <h2>Register</h2>
        <?php if (isset($error_message)) { ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php } ?>
        <div class="mb-3">
            <label for="NamaLengkap" class="form-label">Nama Lengkap</label>
            <input type="text" name="NamaLengkap" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="Username" class="form-label">Username</label>
            <input type="text" name="Username" class="form-control" required>
        </div>
        <!-- Removed the Peran selection field -->
        <div class="mb-3">
            <label for="Email" class="form-label">Email</label>
            <input type="email" name="Email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="Password" class="form-label">Password</label>
            <input type="password" name="Password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="Alamat" class="form-label">Alamat</label>
            <textarea name="Alamat" class="form-control" rows="3" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary w-100">Register</button>
        <p class="text-center mt-3">Sudah punya akun? <a href="login.php" class="text-link">Login di sini</a></p>
    </form>
</div>
</body>
</html>
