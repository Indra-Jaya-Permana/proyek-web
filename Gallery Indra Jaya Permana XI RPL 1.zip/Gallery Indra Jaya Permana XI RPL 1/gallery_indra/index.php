<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang di Portify</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Arial', sans-serif;
            color: #333;
        }

        .logo {
            width: 150px;
            margin: 20px auto;
            display: block;
        }

        /* Header */
        header {
            padding: 15px 0;
            background-color: #007bff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        header h1 {
            font-size: 1.8rem;
            font-weight: bold;
            color: white;
        }
        header .nav-link, .btn-login {
            color: #fff;
            transition: color 0.3s, background-color 0.3s;
            margin-left: 15px;
        }
        header .btn-login {
            background-color: #fff;
            color: #007bff;
            border-radius: 5px;
            padding: 10px 15px;
        }
        header .btn-login:hover {
            background-color: #e2e6ea;
            color: #007bff;
        }

        /* Hero Section */
        .hero {
            height: 90vh;
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('Uploads/baground1.jpg') no-repeat center center/cover;
            color: white;
            padding: 80px 0;
            text-align: center;
            
        }
        .hero h1 {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        .hero p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        /* Features Section */
        .features {
            padding: 60px 0;
            background-color: #fff; /* Warna hitam dominan */
            color: white; /* Teks putih agar kontras */
        }
        .a{
            color: black;
        }
        .feature-item {
            text-align: center;
            margin-bottom: 30px;
            transition: transform 0.3s, box-shadow 0.3s;
            padding: 20px;
            border-radius: 10px;
            background-color: #4a4a4b; /* Warna hitam keabu-abuan */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .feature-item i {
            font-size: 3rem;
            color: #f8c146; /* Warna kuning mencolok */
        }
        .feature-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
        }

        /* Animasi Mengetik */
    .typing-text {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        border-right: 2px solid white;
        animation: typing 6s steps(60, end), blink 0.6s step-end infinite alternate;
        font-size: 1.2rem;
    }

    @keyframes typing {
        0% {
            width: 0;
        }
        100% {
            width: 100%; /* Menyelesaikan seluruh teks */
        }
    }

    @keyframes blink {
        0%, 100% {
            border-color: transparent;
        }
        50% {
            border-color: white;
        }
    }

    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container d-flex justify-content-between align-items-center">
            <h1 class="m-0">Portify</h1>
            <nav>
                <ul class="nav">
                    <a href="login.php" class="btn btn-login">Login</a>
                    <a href="register.php" class="btn btn-login">Daftar</a>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <div class="hero">
        <div class="container">
            <img class="logo" src="Uploads/logo.png" alt="Logo">
            <h1>Selamat Datang di Portify</h1>
            <p class="typing-text">Platform modern untuk mengelola dan berbagi foto. Temukan pengalaman terbaik dengan desain kami yang user-friendly.</p>
        </div>
    </div>

    <!-- Features Section-->
     <div class="features">
        <div class="container">
            <h2 class="text-center mb-5 a">Fitur Utama</h2>
            <div class="row">
                <div class="col-md-4 feature-item">
                    <i class="bi bi-image"></i>
                    <h3>Unggah Foto</h3>
                    <p>Mudah mengunggah foto dengan antarmuka yang intuitif.</p>
                </div>
                <div class="col-md-4 feature-item">
                    <i class="bi bi-share"></i>
                    <h3>Bagikan dengan Teman</h3>
                    <p>Bagikan foto Anda dengan teman dan keluarga dengan mudah.</p>
                </div>
                <div class="col-md-4 feature-item">
                    <i class="bi bi-heart"></i>
                    <h3>Dapatkan Umpan Balik</h3>
                    <p>Terima komentar dan suka dari pengguna lain.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->   
    <?php include 'footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>