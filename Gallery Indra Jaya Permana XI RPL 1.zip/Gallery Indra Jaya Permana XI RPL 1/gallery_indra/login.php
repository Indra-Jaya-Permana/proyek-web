<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .form-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .btn.white {
            background-color: #007bff;
            color: white;
        }

        .btn.white:hover {
            background-color: #0056b3;
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }

        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Tombol Kembali -->
    <form action="index.php" method="POST" style="position: relative;">
        <button type="submit" class="back-button">
            ←
        </button>
    </form>

    <!-- Form Login -->
    <div class="form-container">
        <form action="ceklogin.php" method="POST">
            <h2>Login</h2>
            <div class="mb-3">
                <label for="Username" class="form-label">Username</label>
                <input type="text" name="Username" id="Username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="Password" class="form-label">Password</label>
                <input type="password" name="Password" id="Password" class="form-control" required>
            </div>
            <button type="submit" class="btn w-100 white">Login</button>
            <p class="text-center mt-3">Belum punya akun? <a href="register.php" class="text-link">Daftar di sini</a></p>
        </form>
    </div>
</body>
</html>
