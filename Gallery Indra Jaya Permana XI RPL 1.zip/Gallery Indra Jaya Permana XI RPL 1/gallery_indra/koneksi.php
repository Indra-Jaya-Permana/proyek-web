<?php
$con = mysqli_connect("localhost", "root", "", "gallerydb_indra");

if (!$con) {
    die(json_encode([
        "status" => "error",
        "message" => "Gagal terhubung ke database: " . mysqli_connect_error()
    ]));
}
?>
