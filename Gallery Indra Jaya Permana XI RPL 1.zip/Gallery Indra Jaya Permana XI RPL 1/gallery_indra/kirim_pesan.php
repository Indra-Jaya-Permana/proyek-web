<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $subjek = mysqli_real_escape_string($con, $_POST['subject']);
    $pesan = mysqli_real_escape_string($con, $_POST['message']);

    $query = "INSERT INTO pesan (nama, email, subjek, pesan) VALUES ('$nama', '$email', '$subjek', '$pesan')";
    if (mysqli_query($con, $query)) {
        echo "<script>alert('Pesan berhasil dikirim!'); window.location.href = 'contact.php';</script>";
    } else {
        echo "<script>alert('Gagal mengirim pesan.'); window.location.href = 'contact.php';</script>";
    }
}
?>
