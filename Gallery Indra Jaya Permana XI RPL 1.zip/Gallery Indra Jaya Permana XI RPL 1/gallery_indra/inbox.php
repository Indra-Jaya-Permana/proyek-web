<?php
include "header.php";
include "koneksi.php";

// Periksa apakah pengguna adalah admin
if ($_SESSION['PeranID'] != 1) {
    echo "<script>alert('Anda tidak memiliki akses ke halaman ini.'); window.location.href = 'index.php';</script>";
    exit();
}

// Fungsi untuk menghapus pesan
if (isset($_POST['hapus'])) {
    $id = $_POST['id'];
    $deleteQuery = "DELETE FROM pesan WHERE id = '$id'";
    if (mysqli_query($con, $deleteQuery)) {
        echo "<script>alert('Pesan berhasil dihapus!'); window.location.href = 'inbox.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus pesan!');</script>";
    }
}

// Ambil data pesan dari database
$query = "SELECT * FROM pesan ORDER BY tanggal_kirim DESC";
$result = mysqli_query($con, $query);
?>

<section class="container py-5">
    <h2 class="text-center text-primary mb-4">Inbox Pesan</h2>
    <div class="row">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card shadow-lg border-0 h-100">
                        <div class="card-body">
                            <h5 class="card-title text-primary fw-bold"><?= htmlspecialchars($row['subjek']); ?></h5>
                            <h6 class="card-subtitle mb-3 text-muted">Dari: <?= htmlspecialchars($row['nama']); ?> (<?= htmlspecialchars($row['email']); ?>)</h6>
                            <p class="card-text text-secondary"><?= nl2br(htmlspecialchars($row['pesan'])); ?></p>
                        </div>
                        <div class="card-footer bg-light d-flex justify-content-between align-items-center">
                            <small class="text-muted">Dikirim: <?= htmlspecialchars($row['tanggal_kirim']); ?></small>
                            <form method="POST" class="m-0">
                                <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                <button type="submit" name="hapus" class="btn btn-sm btn-danger">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning text-center">Belum ada pesan yang masuk.</div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include "footer.php"; ?>
