<?php
include "koneksi.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['UserID'])) {
        http_response_code(403);
        echo "<script>alert('Anda harus login untuk mengirim komentar.');</script>";
        exit();
    }

    $fotoID = intval($_POST['fotoid']);
    $isiKomentar = mysqli_real_escape_string($con, $_POST['isikomentar']);
    $userID = $_SESSION['UserID'];

    $query = "INSERT INTO komentarfoto (FotoID, UserID, IsiKomentar, TanggalKomentar) VALUES (?, ?, ?, NOW())";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 'iis', $fotoID, $userID, $isiKomentar);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Komentar berhasil ditambahkan.'); window.location.href = document.referrer;</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan saat menambahkan komentar.'); window.location.href = document.referrer;</script>";
    }
}
?>
