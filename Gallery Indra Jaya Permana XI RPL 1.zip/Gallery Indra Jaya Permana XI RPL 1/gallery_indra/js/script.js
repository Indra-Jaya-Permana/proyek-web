$(document).ready(function () {
    $(".like-btn").click(function () {
        const FotoID = $(this).data("fotoid");
        const likeButton = $(this); // Tombol Like
        const likeCountElement = $(this).find(".like-count");

        $.ajax({
            url: "proses_like.php",
            type: "POST",
            data: { FotoID: FotoID },
            dataType: "json",
            success: function (response) {
                if (response.status === "liked") {
                    likeButton.addClass("liked"); // Tambahkan kelas 'liked' untuk ikon merah
                    likeCountElement.text(response.JumlahLike); // Update jumlah Like
                } else if (response.status === "unliked") {
                    likeButton.removeClass("liked"); // Hapus kelas 'liked'
                    likeCountElement.text(response.JumlahLike); // Update jumlah Like
                } else {
                    alert(response.message);
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX Error:", xhr.responseText);
                alert("Terjadi kesalahan. Coba lagi nanti.");
            }
        });
    });
});
