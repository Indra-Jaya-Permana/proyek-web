<?php include "header.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Portify</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }

        .logo {
            width: 150px;
            margin: 20px auto;
            display: block;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('Uploads/hero-background.jpg') no-repeat center center/cover;
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        .hero h1 {
            font-size: 4rem;
            font-weight: 800;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.7);
        }
        .hero p {
            font-size: 1.3rem;
            margin-bottom: 30px;
        }
        .hero .btn {
            font-size: 1rem;
            padding: 10px 30px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 30px;
        }
        .hero .btn:hover {
            background-color: #0056b3;
        }

        /* Features Section */
        .features {
            padding: 60px 0;
            background-color: #fff; /* Warna hitam dominan */
            color: white; /* Teks putih agar kontras */
        }
        .feature-item {
            text-align: center;
            margin-bottom: 30px;
            transition: transform 0.3s, box-shadow 0.3s;
            padding: 20px;
            border-radius: 10px;
            background-color: #4a4a4b; /* Warna hitam keabu-abuan */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            color: white;
        }
        .feature-item i {
            font-size: 3rem;
            color: #f8c146; /* Warna kuning mencolok */
        }
        .feature-item:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>

<body>
    <!-- <div class="container text-center">
        <img class="logo" src="Uploads/logo.png" alt="Logo">
        <p class="lead">Platform modern untuk mengelola dan berbagi foto. Temukan pengalaman terbaik dengan desain kami yang user-friendly.</p>
    </div> -->

    <!-- Hero Section -->
    <div class="hero">
    <img class="logo" src="Uploads/logo.png" alt="Logo">
        <h1>Seputar Tentang Portify</h1>
        <p>Platform terbaik untuk berbagi kenangan Anda dalam bentuk foto.</p>
        <a href="#features" class="btn">Jelajahi Fitur</a>
    </div>

    <!-- Features Section -->
    <div class="container mt-5" id="features">
        <h2 class="text-center mb-5">Fitur Utama</h2>
        <div class="row">
            <div class="col-md-4 feature-item">
                <i class="bi bi-image"></i>
                <h3>Unggah Foto</h3>
                <p>Mudah mengunggah foto dengan antarmuka yang intuitif.</p>
            </div>
            <div class="col-md-4 feature-item">
                <i class="bi bi-share"></i>
                <h3>Bagikan dengan Teman</h3>
                <p>Bagikan foto Anda dengan teman dan keluarga dengan mudah.</p>
            </div>
            <div class="col-md-4 feature-item">
                <i class="bi bi-heart"></i>
                <h3>Dapatkan Umpan Balik</h3>
                <p >Terima komentar dan suka dari pengguna lain.</p>
            </div>
        </div>
    </div>

<?php include "footer.php"; ?>
</body>
</html>