<?php
session_start();
include "koneksi.php";

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

// Proses upload foto
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = $_POST['tanggal'];
    $albumID = $_POST['album'];
    $foto = $_FILES['foto'];
    $userID = $_SESSION['UserID'];

    // Lokasi direktori untuk menyimpan file upload
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($foto["name"]);

    // Upload file
    if (move_uploaded_file($foto["tmp_name"], $targetFile)) {
        $query = "INSERT INTO foto (JudulFoto, DeskripsiFoto, TanggalUnggah, LokasiFoto, AlbumID, UserID) 
                  VALUES ('$judul', '$deskripsi', '$tanggal', '{$foto['name']}', '$albumID', '$userID')";
        if (mysqli_query($con, $query)) {
            header("Location: dashboard.php");
        } else {
            echo "Terjadi kesalahan: " . mysqli_error($con);
        }
    } else {
        echo "Gagal mengupload foto.";
    }
}
?>
