<?php
session_start();
include "header.php";
include "koneksi.php";

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

$Username = $_SESSION['Username'];

// Ambil data Album dari database
$query_album = "SELECT * FROM album";
$result_album = mysqli_query($con, $query_album);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Foto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div class="container py-4">
        <center><h2 class="mb-4">Form Upload Foto</h2></center>
        <hr>

        <form action="proses_upload.php" method="POST" enctype="multipart/form-data">
            <!-- Title field -->
            <div class="mb-3">
                <label for="judul" class="form-label">Judul Foto:</label>
                <input id="judul" name="judul" type="text" class="form-control" required>
            </div>

            <!-- Description field -->
            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi Foto:</label>
                <textarea id="deskripsi" name="deskripsi" class="form-control" rows="4" required></textarea>
            </div>

            <!-- Date field -->
            <div class="mb-3">
                <label for="tanggal" class="form-label">Tanggal Unggah:</label>
                <input id="tanggal" name="tanggal" type="date" class="form-control" required>
            </div>

            <!-- File upload field -->
            <div class="mb-3">
                <label for="foto" class="form-label">Upload Foto:</label>
                <input id="foto" name="foto" type="file" class="form-control" required>
            </div>

            <!-- Album selection -->
            <div class="mb-3">
                <label for="album" class="form-label">Album:</label>
                <select id="album" name="album" class="form-select" required>
                    <option disabled selected value="">Pilih Album</option>
                    <?php 
                    while ($row = mysqli_fetch_assoc($result_album)) {
                        echo "<option value='{$row['AlbumID']}'>{$row['NamaAlbum']}</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Buttons -->
            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Kirim</button>
                <a href="dashboard.php" class="btn btn-secondary">Batal</a>
            </div>
        </form>
    </div>

    <!-- Footer -->
    <?php include "footer.php"; ?>

</body>
</html>