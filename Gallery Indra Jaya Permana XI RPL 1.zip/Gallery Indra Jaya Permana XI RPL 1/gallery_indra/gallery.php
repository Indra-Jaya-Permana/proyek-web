<?php
include "header.php";
include "koneksi.php";

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

$Username = $_SESSION['Username'];
$PeranID = $_SESSION['PeranID'];

// Query untuk mendapatkan semua album
$albumQuery = mysqli_query($con, "SELECT AlbumID, NamaAlbum FROM album");

// Variabel untuk search dan filter
$searchKeyword = isset($_GET['search']) ? $_GET['search'] : '';
$filterAlbum = isset($_GET['album']) ? $_GET['album'] : '';

// Query untuk mendapatkan data foto dengan search dan filter
$query = "
    SELECT 
        f.FotoID, f.JudulFoto, f.DeskripsiFoto, f.TanggalUnggah, f.LokasiFoto, 
        a.NamaAlbum, u.Username, 
        (SELECT COUNT(*) FROM komentarfoto WHERE FotoID = f.FotoID) AS JumlahKomentar,
        (SELECT COUNT(*) FROM likefoto WHERE FotoID = f.FotoID) AS JumlahLike
    FROM foto f
    JOIN album a ON f.AlbumID = a.AlbumID
    JOIN user u ON f.UserID = u.UserID
    WHERE f.JudulFoto LIKE '%$searchKeyword%'
";

if ($filterAlbum !== '') {
    $query .= " AND a.AlbumID = '$filterAlbum'";
}

$query .= " ORDER BY f.FotoID ASC";
$fotoQuery = mysqli_query($con, $query);
?>

<style>
/* Modal Styling */
#commentsModal .modal-dialog {
    max-width: 500px; /* Lebar maksimum modal */
    margin: auto;
}

#commentsModal .modal-content {
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

#commentsModal .list-group-item {
    padding: 15px;
    margin-bottom: 5px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background-color: #f9f9f9;
}

#commentsModal .list-group-item strong {
    color: #333;
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

#commentsModal .list-group-item small {
    color: #777;
    font-size: 12px;
    display: block;
    margin-bottom: 10px;
}

/* Pastikan backdrop mencakup seluruh layar */
.modal-backdrop {
    position: fixed; /* Pastikan backdrop tetap di posisi tetap */
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5); /* Warna hitam dengan transparansi */
}

/* Modal Styling */
#commentsModal .modal-dialog {
    width: 1100px; /* Lebar maksimum modal */
    margin: auto; /* Mengatur margin otomatis untuk pusat */
    position: fixed; /* Pastikan modal tetap di posisi tetap */
    top: 50%; /* Posisikan modal di tengah vertikal */
    left: 50%; /* Posisikan modal di tengah horizontal */
    transform: translate(-50%, -50%); /* Pindahkan modal ke tengah */
    
}

#commentsModal .modal-body {
    max-height: 400px; /* Atur tinggi maksimum modal */
    overflow-y: auto; /* Tambahkan scroll jika konten melebihi tinggi maksimum */
}

/* Not Found Style */
.not-found {
        text-align: center;
        padding: 60px 20px;
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .not-found h3 {
        font-size: 2rem;
        font-weight: 700;
        color: #d9534f;
    }

    .not-found p {
        font-size: 1rem;
        color: #777;
    }
</style>

<div class="container py-4">
    <h2 class="mb-4 text-center">Gallery Portify</h2>

    <!-- Form Search dan Filter -->
    <form method="GET" class="mb-4">
        <hr>
        <div class="row">
            <div class="col-md-6">
                <input type="text" name="search" class="form-control" placeholder="Cari judul foto..." value="<?php echo $searchKeyword; ?>">
            </div>
            <div class="col-md-4">
                <select name="album" class="form-select">
                    <option value="">Semua Album</option>
                    <?php while ($album = mysqli_fetch_assoc($albumQuery)): ?>
                        <option value="<?php echo $album['AlbumID']; ?>" <?php if ($album['AlbumID'] == $filterAlbum) echo 'selected'; ?>>
                            <?php echo $album['NamaAlbum']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
        <hr>
    </form>

    <div class="row">
        <?php while ($foto = mysqli_fetch_assoc($fotoQuery)): ?>
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm">
                    <img src="uploads/<?php echo $foto['LokasiFoto']; ?>" class="card-img-top" alt="<?php echo $foto['JudulFoto']; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $foto['JudulFoto']; ?></h5>
                        <p class="card-text text-muted"><?php echo $foto['DeskripsiFoto']; ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <!-- Tombol Like -->
                            <button class="btn btn-outline-danger like-btn" data-fotoid="<?php echo $foto['FotoID']; ?>">
                                <i class="bi bi-heart"></i>
                                <span class="like-count"><?php echo $foto['JumlahLike']; ?></span>
                            </button>
                            <!-- Tombol Komentar dan Share -->
                            <div class="d-flex align-items-center">
                                <button class="btn btn-sm btn-outline-secondary view-comments" data-fotoid="<?php echo $foto['FotoID']; ?>">
                                    <i class="bi bi-chat-dots"></i> <?php echo $foto['JumlahKomentar']; ?>
                                </button>
                                <p>&nbsp;</p>
                                <a href="https://www.whatsapp.com/sharer/sharer.php?u=uploads/<?php echo $foto['LokasiFoto']; ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-share"></i>
                                </a>
                            </div>
                        </div>
                        <!-- Form Komentar -->
                        <form method="POST" action="submit_komentar.php" class="mt-3 submit-comment-form">
                            <input type="hidden" name="fotoid" value="<?php echo $foto['FotoID']; ?>">
                            <div class="mb-2">
                                <textarea name="isikomentar" class="form-control" rows="2" placeholder="Tulis komentar..."></textarea>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary">Kirim Komentar</button>
                        </form>
                        <!-- Tombol hanya muncul jika PeranID adalah 1 -->
                        <?php if ($PeranID == 1): ?>
                        <div class="mt-2">
                            <a href="edit.php?id=<?php echo $foto['FotoID']; ?>" class="btn btn-primary btn-sm">Edit</a>
                            <a href="delete.php?id=<?php echo $foto['FotoID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus foto ini?')">Delete</a>
                            <a href="info.php?id=<?php echo $foto['FotoID']; ?>" class="btn btn-secondary btn-sm">Info</a>
                        </div>
                        <?php endif; ?>
                        <?php if ($PeranID == 2): ?>
                        <div class="mt-2">
                            <a href="info.php?id=<?php echo $foto['FotoID']; ?>" class="btn btn-secondary btn-sm">Info</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>

        <?php if (mysqli_num_rows($fotoQuery) === 0): ?>
            <!-- Jika tidak ada hasil -->
            <div class="not-found">
                    <h3>Foto tidak ditemukan</h3>
                    <p>Coba gunakan kata kunci atau filter yang berbeda.</p>
                </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Komentar -->
<div class="modal fade" id="commentsModal" tabindex="-1" aria-labelledby="commentsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="commentsModalLabel">Komentar</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ul class="list-group list-group-flush" id="commentsList"></ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="js/script.js"></script>
<script>
$(document).ready(function () {
    // Event untuk membuka modal komentar
    $('.view-comments').on('click', function () {
        const fotoID = $(this).data('fotoid');

        // AJAX untuk mendapatkan komentar
        $.ajax({
            url: 'get_komentar.php',
            method: 'GET',
            data: { fotoid: fotoID },
            success: function (data) {
                const comments = JSON.parse(data);
                const commentsList = $('#commentsList');
                commentsList.empty();

                if (comments.length === 0) {
                    commentsList.append('<li class="list-group-item text-center">Belum ada komentar.</li>');
                } else {
                    comments.forEach(comment => {
                        commentsList.append(`
                            <li class="list-group-item">
                                <strong>${comment.Username}</strong>
                                <small>${new Date(comment.TanggalKomentar).toLocaleString()}</small>
                                <p>${comment.IsiKomentar}</p>
                            </li>
                        `);
                    });
                }

                $('#commentsModal').modal('show');
            },
            error: function () {
                alert('Gagal memuat komentar.');
            }
        });
    });

    // Memastikan modal tetap terlihat dengan baik saat viewport berubah
    $(window).on('resize', function () {
        $('#commentsModal').modal('handleUpdate');
    });
});
</script>

<?php include "footer.php"; ?>
