<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$PeranID = $_SESSION['PeranID'];
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <style>
        /* Gaya menu aktif */
        .nav-link.active {
            font-weight: bold;
            border-bottom: 2px solid white;
        }

        /* Stabilkan ukuran logo */
        .header-logo img {
            max-height: 100px;
            object-fit: contain;
            transition: none; /* Tidak ada efek transisi pada logo */
        }

        .admin-style {
            font-weight: bold;
            font-size: 30px;
        }

        .user-style {
            font-weight: none;
            font-size: 25px;
        }

        /* Animasi slide-in */
        .slide-in {
            opacity: 0;
            transform: translateY(-20px);
            animation: slideIn 0.5s forwards;
        }

        @keyframes slideIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Transisi hover untuk link navigasi */
        .nav-link {
            transition: color 0.3s ease;
        }

        .nav-link:hover {
            color: #ffcc00; /* Ganti warna saat hover */
        }
    </style>
</head>
<body class="slide-in">
    <header class="bg-primary text-white slide-in">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="header-logo">
                <h1 class="a <?php echo ($PeranID == 1) ? 'admin-style' : 'user-style'; ?>"> <img src="Uploads/logo.png" alt="Logo"> Portify</h1>
            </div>
            <nav>
                <ul class="nav">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link text-white <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="gallery.php" class="nav-link text-white <?php echo ($current_page == 'gallery.php') ? 'active' : ''; ?>">Gallery</a>
                    </li>
                    <li class="nav-item">
                        <a href="about.php" class="nav-link text-white <?php echo ($current_page == 'about.php') ? 'active' : ''; ?>">About</a>
                    </li>
                    <?php if ($PeranID == 1): ?>
                    <li class="nav-item">
                        <a href="inbox.php" class="nav-link text-white <?php echo ($current_page == 'inbox.php') ? 'active' : ''; ?>">Inbox</a>
                    </li>
                    <?php endif; ?>
                    <?php if ($PeranID == 2): ?>
                    <li class="nav-item">
                        <a href="contact.php" class="nav-link text-white <?php echo ($current_page == 'contact.php') ? 'active' : ''; ?>">Contact</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <div class="d-flex gap-2">
                <?php if ($PeranID == 1): ?>
                    <a href="tambah_album.php" class="btn btn-danger">
                        <i></i> Album
                    </a>
                    <a href="upload.php" class="btn btn-danger">
                        <i class="bi bi-upload"></i> Upload
                    </a>
                <?php endif; ?>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>
    </header>
</body>
</html>